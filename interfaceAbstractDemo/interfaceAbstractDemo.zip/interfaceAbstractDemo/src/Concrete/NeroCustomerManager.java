package Concrete;

import Abstract.BaseCustomerManager;

public class NeroCustomerManager extends BaseCustomerManager {
}
