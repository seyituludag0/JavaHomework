package Abstract;

import Entities.Customer;

public interface CustomerCheckService {
     boolean checkPersonService(Customer customer);

}
