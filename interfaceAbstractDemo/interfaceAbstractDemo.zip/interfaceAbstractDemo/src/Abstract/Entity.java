package Abstract;

public interface Entity {
}
